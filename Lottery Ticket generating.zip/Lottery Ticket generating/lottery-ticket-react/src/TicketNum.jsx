import "./TicketNum.css"
export default function TicketNum({num}){
    return <span className = "TicketNum">{num}</span>
}